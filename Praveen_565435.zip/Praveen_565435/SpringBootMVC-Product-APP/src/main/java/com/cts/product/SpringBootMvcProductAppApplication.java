package com.cts.product;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMvcProductAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMvcProductAppApplication.class, args);
	}

}
